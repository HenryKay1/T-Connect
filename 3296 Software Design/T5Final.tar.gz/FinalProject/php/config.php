<?php

	define("SERVER", "cis-linux2.temple.edu");
	define("USER","tul46491");
	define("PASSWORD","ainumoob");
	define("DATABASE","FA20_3296_tul46491");

?>