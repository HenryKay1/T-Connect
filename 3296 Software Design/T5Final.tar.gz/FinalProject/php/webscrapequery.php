<?php
	session_start();
	require_once("config.php");
   
	$con = mysqli_connect(SERVER,USER,PASSWORD,DATABASE);
	
	if(!$con){
	echo "Cannot connect to Database. ".mysqli_error($con)."";
	exit();
	}
	print "Database Connected";
	
	//Query to a new database that handles courses and such
	//echo $courseObject->courseTag;
	//echo $courseObject->courseNumber;
	//echo $courseObject->courseName;
	
	//Run query to see if courseTag exists
	$query = "SELECT courseTag FROM CoursesList WHERE courseTag = '$courseObject->CourseTag'";
	$result = mysqli_query($con, $query);
	//If it doesn't exist, add to database
	if ($result->num_rows == 0){
		$query = "INSERT INTO CoursesList(CourseTag, CourseNumber, CourseName) values ('$courseObject->courseTag','$courseObject->courseNumber','$courseObject->courseName');";
		mysqli_query($con, $query);
	//If it does, then update the database
	} else {
		$query = "UPDATE CoursesList SET CourseNumber = '$courseObject->courseNumber', CourseName = '$courseObject->courseName' WHERE CourseTag = $courseObject->courseTag;";
		mysqli_query($con, $query);
	}

?>