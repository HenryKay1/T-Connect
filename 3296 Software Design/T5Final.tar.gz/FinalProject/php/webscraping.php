<?php

//tul46491 = Henry. look at his databases for stuff

require 'simple_html_dom.php';


//Base site. This is primarily for Temple Courses
$html = file_get_html('https://bulletin.temple.edu/courses/');

//Find div with courses
$es = $html->find('div[class="sitemap"]', 0);
//Finds the href in each of the courses in that div
foreach($es -> find ('a') as $element){
	//New html that goes into that specific course
	$html = file_get_html('https://bulletin.temple.edu'.$element ->href);
	
	//Loop to get each course in that new html
	$iterator = 0;
	$list = $html->find('div[class="courseblock"]', $iterator);
	while ($list != null){
		$list_array = $list -> find('p[class="courseblocktitle"]');
		for ($i = 0; $i < sizeof($list_array); $i++) {
			$course = $list_array[$i] -> plaintext;
			$temp = parseCourse($course);
			//echo $temp;
			//echo "<br>";
		}
		$iterator++;
		$list = $html->find('div[class="courseblock"]', $iterator);
	}
}


function parseCourse($string){
	$newString = substr($string, 0, strripos($string, "."));
	$newString = substr($string, 0, strripos($newString, "."));
	
	$courseTag = substr($newString, 0, strripos($newString, ".") - 4);
	$courseNumber = substr($newString, strripos($newString, ".") - 4, 4);
	$courseName = substr($newString, strripos($newString, ".") + 3, strlen($newString) - strripos($newString, "."));
	
	$courseObject = new courseObject($courseTag, $courseName, $courseNumber);
	
	//echo $courseObject->courseTag;
	//echo $courseObject->courseNumber;
	//echo $courseObject->courseName;
	
	//Run server php script that inserts/updates
	include('webscrapequery.php');
	
	return $newString;
}

class courseObject
{
	public $courseTag;
	public $courseName;
	public $courseNumber;
	
	public function __construct(string $courseTag, string $courseName, string $courseNumber){
		$this->courseTag = $courseTag;
		$this->courseName = $courseName;
		$this->courseNumber = $courseNumber;
	}
}

?>