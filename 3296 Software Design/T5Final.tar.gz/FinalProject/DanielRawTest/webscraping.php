<?php
error_reporting(E_ALL); ini_set('display_errors', 1);
ini_set('max_execution_time', 0);


//require("config2.php");
require 'simple_html_dom.php';
require 'config.php';

$con = mysqli_connect(SERVER,USER,PASSWORD,DATABASE);
$query = "TRUNCATE TABLE CoursesList";
mysqli_query($con, $query);

//Base site. This is primarily for Temple Courses
$html = file_get_html('https://bulletin.temple.edu/courses/');
//Find div with courses
$es = $html->find('div[class="sitemap"]', 0);

//Finds the href in each of the courses in that div
foreach($es -> find ('a') as $element){
	//New html that goes into that specific course
	$html = file_get_html('https://bulletin.temple.edu'.$element ->href);
	//Loop to get each course in that new html
	$iterator = 0;
	$list = $html->find('div[class="courseblock"]', $iterator);
	while ($list != null){
		$list_array = $list -> find('p[class="courseblocktitle"]');
		for ($i = 0; $i < sizeof($list_array); $i++) {
			$course = $list_array[$i] -> plaintext;
			$temp = parseCourse($course);
			//echo $temp;
			//echo "<br>";
		}
		$iterator++;
		$list = $html->find('div[class="courseblock"]', $iterator);
	}
}
print 'Courses have all been added to the database';

function parseCourse($string){
	$newString = substr($string, 0, strripos($string, "."));
	$newString = substr($string, 0, strripos($newString, "."));

	//echo $newString;
	
	$courseTag = substr($newString, 0, strpos($newString, "&#160"));
	rtrim ($courseTag);
	$courseNumber = substr($newString, strpos($newString, ".") - 4, 4);
	$courseName = substr($newString, strpos($newString, ".") + 1, strlen($newString) - strpos($newString, "."));
	if (strpos($courseName, '1') !== false || strpos($courseName, '2') !== false || strpos($courseName, '3') !== false || strpos($courseName, '4') !== false){
		$courseName = substr($courseName, 0, strlen($courseName) - 2);
	}

	//echo $courseTag;
	//echo $courseNumber;
	//echo $courseName;
	//echo "<br>";
	
	//Run server php script that inserts/updates
	$con = mysqli_connect(SERVER,USER,PASSWORD,DATABASE);
	$query = "INSERT INTO CoursesList(CourseTag, CourseNumber, CourseName) values ('$courseTag','$courseNumber','$courseName');";
	mysqli_query($con, $query);

	
	return $newString;
}

?>